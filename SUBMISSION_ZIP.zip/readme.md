Homework 2
